//
//  LoginViewController.h
//  ParseStarterProject
//
//  Created by Joy on 2/18/15.
//
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController


- (IBAction)loginButton:(id)sender;

@property (weak, nonatomic) IBOutlet UITextField *loginUsernameField;
@property (weak, nonatomic) IBOutlet UITextField *loginPasswordField;

@end
