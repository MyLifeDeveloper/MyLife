//
//  SignupViewController.h
//  ParseStarterProject
//
//  Created by Joy on 2/18/15.
//
//

#import <UIKit/UIKit.h>

@interface SignupViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *signupUsernameField;
@property (weak, nonatomic) IBOutlet UITextField *signupPasswordField;
- (IBAction)signupButton:(id)sender;

@end
