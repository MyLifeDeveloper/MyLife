//
//  SweetTableViewCell.m
//  ParseStarterProject
//
//  Created by Joy on 2/24/15.
//
//

#import "SweetTableViewCell.h"

@implementation SweetTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
