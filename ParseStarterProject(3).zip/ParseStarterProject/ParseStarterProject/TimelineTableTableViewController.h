//
//  TimelineTableTableViewController.h
//  ParseStarterProject
//
//  Created by Joy on 2/24/15.
//
//

#import <UIKit/UIKit.h>

@interface TimelineTableTableViewController : UITableViewController

@end
