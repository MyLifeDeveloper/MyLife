//
//  SignupViewController.m
//  ParseStarterProject
//
//  Created by Joy on 2/18/15.
//
//

#import "SignupViewController.h"
#import <Parse/Parse.h>

@interface SignupViewController ()

@end

@implementation SignupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)signupButton:(id)sender {
    PFUser *user = [PFUser user];
    user.username = _signupUsernameField.text;
    user.password = _signupPasswordField.text;
    //user.email = @"email@example.com";
    
    // other fields can be set if you want to save more information
    //user[@"phone"] = @"650-555-0000";
    UIViewController *next = [[self storyboard] instantiateViewControllerWithIdentifier:@"MainView"];
    
    [self presentModalViewController:next animated:NO];
    [user signUpInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            // Hooray! Let them use the app now.
        } else {
            NSString *errorString = [error userInfo][@"error"];
            // Show the errorString somewhere and let the user try again.
        }
    }];
}
@end
