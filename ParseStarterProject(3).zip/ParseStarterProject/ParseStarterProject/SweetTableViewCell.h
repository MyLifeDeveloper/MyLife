//
//  SweetTableViewCell.h
//  ParseStarterProject
//
//  Created by Joy on 2/24/15.
//
//

#import <UIKit/UIKit.h>

@interface SweetTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *usernamelabel;
@property (strong, nonatomic) IBOutlet UILabel *timestamplabel;
@property (strong, nonatomic) IBOutlet UITextView *sweetTextView;

@end
