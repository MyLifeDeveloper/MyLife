//
//  ComposeViewController.m
//  ParseStarterProject
//
//  Created by Joy on 2/24/15.
//
//

#import "ComposeViewController.h"

#import <Parse/Parse.h>



@interface ComposeViewController ()

@end

@implementation ComposeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)sendSweet:(id)sender {
    PFObject *sweet = [PFObject objectWithClassName:@"sweets"];
    sweet[@"content"] = _sweetTextView.text;
    sweet[@"sweeter"] = [PFUser currentUser];
    [sweet saveInBackground];
    //[[self navigationController] popToRootViewControllerAnimated:true];
    UIViewController *next = [[self storyboard] instantiateViewControllerWithIdentifier:@"MainView"];
    
    //            [self presentModalViewController:next animated:NO];
    [self.navigationController pushViewController:next animated:YES];
}
@end
