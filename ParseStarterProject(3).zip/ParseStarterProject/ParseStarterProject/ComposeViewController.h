//
//  ComposeViewController.h
//  ParseStarterProject
//
//  Created by Joy on 2/24/15.
//
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>
@interface ComposeViewController : UIViewController;
@property (strong, nonatomic) IBOutlet UITextView *sweetTextView;

- (IBAction)sendSweet:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *charRemainingLabel;
@end
